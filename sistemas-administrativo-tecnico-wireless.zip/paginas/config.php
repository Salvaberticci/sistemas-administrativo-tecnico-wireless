<?php
// paginas/config.php - ARCHIVO SENSIBLE NO SUBIR A GIT
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_USERNAME', 'soportegalanetescuque@gmail.com');
define('MAIL_PASSWORD', 'vvik kzmj inal zdwa');
define('MAIL_SMTP_SECURE', 'tls');
define('MAIL_PORT', 587);
define('MAIL_FROM_EMAIL', 'soportegalanetescuque@gmail.com');
define('MAIL_FROM_NAME', 'Wireless Applications Nómina');
?>