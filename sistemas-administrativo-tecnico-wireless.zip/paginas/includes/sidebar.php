<!-- 
    SIDEBAR DEPRECATED 
    This file is intentionally empty as the navigation has moved to header.php (Top Navbar).
    It is kept to prevent errors in existing pages that still include it.
-->
