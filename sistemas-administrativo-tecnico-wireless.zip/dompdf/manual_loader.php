<?php
// Carga manual de las clases de Dompdf
require_once __DIR__ . '/src/Dompdf/Dompdf.php';
require_once __DIR__ . '/src/Dompdf/Options.php';

// Alias para las clases, para que las puedas usar directamente
use Dompdf\Dompdf;
use Dompdf\Options;
?>